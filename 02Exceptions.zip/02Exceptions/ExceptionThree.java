/**
 * Exception example 3
 */
public class ExceptionThree {
    public static void main(String[] args) {
        int num = 32;
        if (num == 32) {
            throw new RuntimeException("num == 32");
            // RuntimeException is not a checked exception
        }
    }
}