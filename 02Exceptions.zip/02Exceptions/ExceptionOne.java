/**
 * Exception example 1
 * This will not compile!
 */
public class ExceptionOne {
    public static void main(String[] args) { // has to have `throws` to compile
        int num = 32;
        if (num == 32) {
            throw new Exception("num == 32");
        }
    }
}