import java.util.Scanner;

/**
 * Exception example 6
 */
public class ExceptionSix {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        System.out.print("Enter an integer >>> ");
        int num = kb.nextInt();
        kb.nextLine();
        int answer = 0;

        try {
            if (num == 0) {
                throw new Exception("num == 0");
            } else {
                answer = 90 / num;
            }
        } catch(NullPointerException e) {
            System.out.println(e + " Exception");
        } catch(ClassCastException e) {
            System.out.println(e + " Exception");
        } catch(Exception e) {
            System.out.println(e + " Exception");
        } finally {
            System.out.println("This always happens!");
        }

        System.out.println("The answer is " + answer);
    }
}