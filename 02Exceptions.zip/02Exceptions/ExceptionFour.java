import java.util.Scanner;

/**
 * Exception example 4
 * This will not compile!
 */
public class ExceptionFour {
    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        System.out.print("Enter an integer >>> ");
        int num = kb.nextInt();
        kb.nextLine();
        int answer = 0;

        try {
            if (num == 0) {
                throw new Exception("num == 0");
            } else {
                answer = 90 / num;
            }
        }

        // Must have a `catch` or `finally` when using `try`

        System.out.println("The answer is " + answer);
    }
}