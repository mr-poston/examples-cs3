// generic comparable example

import static java.lang.System.*;

public class WordRunner
{
    public static void main(String[] args)
    {
        Word x = new Word("dog");
        Word y = new Word("cat");
        System.out.println(x.compareTo(y));
        
        //make a list of Word
        //call Collections.sort() and sort the list
        //print the list
    }
}