//generic comparable example

public class Word implements Comparable<Word> {
    private String orig;
    
    public Word(String s) {
        orig = s;
    }
    
    public int compareTo(Word other) {
        //must add code to complete 
    
        return 1; 
    }
    
    public String toString() {
        return orig;
    }
}