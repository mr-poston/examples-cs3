// interface example

public interface Locatable {
    int getX();
    int getY();
}