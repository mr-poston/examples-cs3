// interface example

public interface Moveable {
    void setPos(int x, int y);
    void setX(int x);
    void setY(int y);
}